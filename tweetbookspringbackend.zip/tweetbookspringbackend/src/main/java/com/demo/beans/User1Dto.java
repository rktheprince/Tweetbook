package com.demo.beans;


public class User1Dto{
	 private int user_id;

	public User1Dto(int user_id) {
		super();
		this.user_id = user_id;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	
//
//	@Override
//	public String toString() {
//		return "User1Dto [user_id=" + user_id + "]";
//	}
//	 
	 
}