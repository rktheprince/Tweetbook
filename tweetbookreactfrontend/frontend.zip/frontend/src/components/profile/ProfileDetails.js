import React from 'react'

export const ProfileDetails = () => {
    return (
        <div>

        </div>
    )
}
